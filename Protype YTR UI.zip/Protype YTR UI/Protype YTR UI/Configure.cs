﻿
using EasyModbus;
using Protype_YTR_UI.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Protype_YTR_UI
{
    public partial class Configure : Form
    {
        int setscale_position = 13;
        int setscale_value = 14;
        int setscale_getvalue = 15;
        int setscale_geteepromaddress = 16;
        int tarescale_position = 17;
        public Configure()
        {
            InitializeComponent();
        }

        private void Configure_Load(object sender, EventArgs e)
        {
            IPSlave1Textbox.Text = Settings.Default["IPSlave1Setting"].ToString();
            IPSlave2Textbox.Text = Settings.Default["IPSlave2Setting"].ToString();
            PortTextbox.Text = Settings.Default["PortSetting"].ToString();
            SQLConnectionStringTextbox.Text = Settings.Default["SQLConnectionStringSetting"].ToString();
            SQLUsernameTextbox.Text = Settings.Default["SQLUsernameSetting"].ToString();
            SQLPasswordTextbox.Text = Settings.Default["SQLPasswordSetting"].ToString();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int postion = 0;
            float tareval = 0;
            if (float.TryParse(ManualTareTextbox.Text, out tareval))
            {
                if (Int32.TryParse(ManualTareCombobox.Text, out postion ))
                {

                    int port = int.Parse(Settings.Default["PortSetting"].ToString());
                    string ip;
                    if (postion > 12)
                    {
                        postion = postion - 12;
                        ip = Settings.Default["IPSlave2Setting"].ToString();
                    }
                    else
                    {
                        ip = Settings.Default["IPSlave1Setting"].ToString();
                    }

                    try
                    {
                        ModbusClient modbusClient = new ModbusClient(ip, port);
                        modbusClient.ConnectionTimeout = 300;
                        modbusClient.Connect();
                        modbusClient.WriteSingleRegister(tarescale_position, postion);
                        modbusClient.Disconnect();
                        Cursor.Current = Cursors.WaitCursor;
                        Thread.Sleep(2000);
                        Cursor.Current = Cursors.Default;
                    }
                    catch (Exception ex)
                    {

                        MessageBox.Show(this, ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    string value = Settings.Default["TareSetting"].ToString();
                    float[] arr = value.Split(',').Select(s => float.Parse(s)).ToArray();
                    arr[postion-1] = tareval;
                    value = string.Join(",", arr.Select(i => i.ToString()).ToArray());
                    try
                    {
                        Settings.Default["TareSetting"] = value;
                        Settings.Default.Save();
                        MessageBox.Show("Tare Complete", "Success!");
                    }
                    catch (Exception ex)
                    {

                        MessageBox.Show(this, ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    
                }
                else
                {
                    MessageBox.Show("Entered Position Value is not a number!", "Inavlid Data");
                }
            }
            else
            {
                MessageBox.Show("Entered Tare Value is not a number!", "Inavlid Data");
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string message = "Have you tare the scale and then placed known weight? \r\n Note: Not applying tare before calibration  \r\n can cause issues. \r\n " +
                "Please wait while system calibrates the sensor!";
            string title = "Alert!";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result = MessageBox.Show(message, title, buttons, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
            if (result == DialogResult.Yes)
            {
                int postion = 0;
                float setscaleval = 0;
                if (float.TryParse(ManualSetScaleTextbox.Text, out setscaleval))
                {
                    if (Int32.TryParse(ManualSetScaleCombobox.Text, out postion))
                    {
                        int port = int.Parse(Settings.Default["PortSetting"].ToString());
                        string ip;
                        setscaleval = setscaleval * 10;
                        int[] val = { postion, (int)setscaleval };
                        int[] returnedsetscale = { 1 };
                        if (postion > 12)
                        {
                            postion = postion - 12;
                            ip = Settings.Default["IPSlave2Setting"].ToString();
                        }
                        else
                        {
                            ip = Settings.Default["IPSlave1Setting"].ToString();
                        }

                        try
                        {
                            ModbusClient modbusClient = new ModbusClient(ip, port);
                            modbusClient.ConnectionTimeout = 300;
                            modbusClient.Connect();
                            modbusClient.WriteMultipleRegisters(setscale_position, val);
                            modbusClient.Disconnect();
                            Cursor.Current = Cursors.WaitCursor;
                            Thread.Sleep(2000);
                            Cursor.Current = Cursors.Default;
                            modbusClient.Connect();
                            returnedsetscale = modbusClient.ReadHoldingRegisters(setscale_getvalue, 1);
                            modbusClient.Disconnect();
                        }
                        catch (Exception ex)
                        {

                            MessageBox.Show(this, ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }

                        string value = Settings.Default["SetScaleSetting"].ToString();
                        float[] arr = value.Split(',').Select(s => float.Parse(s)).ToArray();
                        arr[Int32.Parse(ManualSetScaleCombobox.Text) - 1] = returnedsetscale[0];
                        value = string.Join(",", arr.Select(i => i.ToString()).ToArray());
                        try
                        {
                            Settings.Default["SetScaleSetting"] = value;
                            Settings.Default.Save();
                            MessageBox.Show("SetScale Complete", "Success!");
                        }
                        catch (Exception ex)
                        {

                            MessageBox.Show(this, ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }

                    }
                    else
                    {
                        MessageBox.Show("Entered Position Value is not a number!", "Inavlid Data");
                    }
                }
                else
                {
                    MessageBox.Show("Entered SetScale Value is not a number!", "Inavlid Data");
                }

            }
            else
            {

            }
            
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int position = 0;
            if (Int32.TryParse(ManualSetScaleCombobox.Text, out position))
            {
                string value = Settings.Default["SetScaleSetting"].ToString();
                float[] arr = value.Split(',').Select(s => float.Parse(s)).ToArray();
                ManualSetScaleTextbox.Text = arr[position-1].ToString();

            }
        }

        private void IPSlave1Label_Click(object sender, EventArgs e)
        {

        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            Settings.Default["IPSlave1Setting"] = IPSlave1Textbox.Text;
            Settings.Default["IPSlave2Setting"] = IPSlave2Textbox.Text;
            Settings.Default["PortSetting"] = PortTextbox.Text;
            Settings.Default["SQLConnectionStringSetting"] = SQLConnectionStringTextbox.Text;
            Settings.Default["SQLUsernameSetting"] = SQLUsernameTextbox.Text;
            Settings.Default["SQLPasswordSetting"] = SQLPasswordTextbox.Text;
            try
            {
                Settings.Default.Save();
                MessageBox.Show("Settings Saved", "Success!");
            }
            catch (Exception ex)
            {

                MessageBox.Show(this, ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        private void IPSlave1Textbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void IPSlave2Label_Click(object sender, EventArgs e)
        {

        }

        private void IPSlave2Textbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void PortLabel_Click(object sender, EventArgs e)
        {

        }

        private void PortTextbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void ManualTareLabel_Click(object sender, EventArgs e)
        {

        }

        private void ManualTareCombobox_SelectedIndexChanged(object sender, EventArgs e)
        {
            int position = 0;
            if (Int32.TryParse(ManualTareCombobox.Text, out position))
            {
              string value = Settings.Default["TareSetting"].ToString();
              float[] arr = value.Split(',').Select(s => float.Parse(s)).ToArray();
                ManualTareTextbox.Text = arr[position-1].ToString();
                
            }
        }

        private void AutoTareLabel_Click(object sender, EventArgs e)
        {

        }

        private void AutoTareButton_Click(object sender, EventArgs e)
        {

        }

        private void GetRawValuesTextbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void GetRawValuesButton_Click(object sender, EventArgs e)
        {
            GetRawValuesTextbox.ScrollBars = ScrollBars.Vertical;
            int port = int.Parse(Settings.Default["PortSetting"].ToString());
            try
            {
                string ipslave1 = Settings.Default["IPSlave1Setting"].ToString();
                ModbusClient modbusClient = new ModbusClient(ipslave1, port);
                modbusClient.ConnectionTimeout = 100;
                modbusClient.Connect();
                int[] readHoldingRegisters = modbusClient.ReadHoldingRegisters(0, 12);
                modbusClient.Disconnect();
                string text = null;
                for (int i = 0; i < readHoldingRegisters.Length; i++)
                {
                    text = "Position No. " + (i + 1) + " :" + readHoldingRegisters[i].ToString();
                    GetRawValuesTextbox.AppendText(text + Environment.NewLine);
                }
                    

            }
            catch (Exception ex)
            {

                MessageBox.Show(this, ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            
            try
            {
                string ipslave2 = Settings.Default["IPSlave2Setting"].ToString();
                ModbusClient modbusClient2 = new ModbusClient(ipslave2, port);
                modbusClient2.ConnectionTimeout = 100;
                modbusClient2.Connect();
                int[] readHoldingRegisters2 = modbusClient2.ReadHoldingRegisters(0, 12);
                modbusClient2.Disconnect();
                for (int i = 0; i < readHoldingRegisters2.Length; i++)
                    GetRawValuesTextbox.AppendText("Value of HoldingRegister " + (i + 1 + 12) + " " + readHoldingRegisters2[i].ToString());
            }
            catch (Exception ex)
            {

                MessageBox.Show(this, ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        private void SQLConnectionStringLabel_Click(object sender, EventArgs e)
        {

        }

        private void SQLConnectionStringTextbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void SQLUsernameLabel_Click(object sender, EventArgs e)
        {

        }

        private void SQLUsernameTextbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void SQLPasswordLabel_Click(object sender, EventArgs e)
        {

        }

        private void SQLPasswordTextbox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
