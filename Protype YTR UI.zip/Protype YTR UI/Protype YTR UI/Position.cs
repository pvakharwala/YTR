﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Protype_YTR_UI
{
    public class Position
    {
        public string entrytime { get; }
        public float Position1 { get; set; }
        public float Position2 { get; set; }
        public float Position3 { get; set; }
        public float Position4 { get; set; }
        public float Position5 { get; set; }
        public float Position6 { get; set; }
        public float Position7 { get; set; }
        public float Position8 { get; set; }
        public float Position9 { get; set; }
        public float Position10 { get; set; }
        public float Position11 { get; set; }
        public float Position12 { get; set; }
        public float Position13 { get; set; }
        public float Position14 { get; set; }
        public float Position15 { get; set; }
        public float Position16 { get; set; }
        public float Position17 { get; set; }
        public float Position18 { get; set; }
        public float Position19 { get; set; }
        public float Position20 { get; set; }
        public float Position21 { get; set; }
        public float Position22 { get; set; }
        public float Position23 { get; set; }
        public float Position24 { get; set; }

        
        public float[] PositionData
        {
            get
            {
                float[] positiondata = { Position1, Position2, Position3, Position4, Position5, Position6, 
                    Position7, Position8, Position9, Position10, Position11, Position12, Position13, Position14, 
                    Position15, Position16, Position17, Position18, Position19, Position20, Position21, Position22, 
                    Position23, Position24 };
                return positiondata;
            }
        }
    }
}
