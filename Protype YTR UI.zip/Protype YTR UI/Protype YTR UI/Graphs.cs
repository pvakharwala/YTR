﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace Protype_YTR_UI
{
    public partial class Graphs : Form
    {
        long buttonCount = 0;
        List<Position> positions = new List<Position>();
        DataAccess db = new DataAccess();
        public Graphs()
        {
            InitializeComponent();
        }

        private void Graphs_Load(object sender, EventArgs e)
        {
            FromDatetimepicker.CustomFormat = "yyyy-MM-dd hh:mm:ss";
            Todatetimepicker.CustomFormat = "yyyy-MM-dd hh:mm:ss";
        }

        private void chart1_MouseWheel(object sender, MouseEventArgs e)
        {
            var chart = (Chart)sender;
            var xAxis = chart.ChartAreas[0].AxisX;
            var yAxis = chart.ChartAreas[0].AxisY;

            try
            {
                if (e.Delta < 0) // Scrolled down.
                {
                    xAxis.ScaleView.ZoomReset();
                    yAxis.ScaleView.ZoomReset();
                }
                else if (e.Delta > 0) // Scrolled up.
                {
                    var xMin = xAxis.ScaleView.ViewMinimum;
                    var xMax = xAxis.ScaleView.ViewMaximum;
                    var yMin = yAxis.ScaleView.ViewMinimum;
                    var yMax = yAxis.ScaleView.ViewMaximum;

                    var posXStart = xAxis.PixelPositionToValue(e.Location.X) - (xMax - xMin) / 1;
                    var posXFinish = xAxis.PixelPositionToValue(e.Location.X) + (xMax - xMin) / 1;
                    var posYStart = yAxis.PixelPositionToValue(e.Location.Y) - (yMax - yMin) / 1;
                    var posYFinish = yAxis.PixelPositionToValue(e.Location.Y) + (yMax - yMin) / 1;

                    xAxis.ScaleView.Zoom(posXStart, posXFinish);
                    yAxis.ScaleView.Zoom(posYStart, posYFinish);
                }
            }
            catch { }
        }

        private void GetGraphButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (buttonCount == 0)
                {
                    chart1.Series[0].IsVisibleInLegend = false;
                }
                if (buttonCount > 0)
                {
                    chart1.Series.Clear();
                }
                buttonCount++;

                var s = FromDatetimepicker.Value.ToString("yyyy-MM-dd hh:mm:ss");
                var firstSpaceIndex = s.IndexOf(" ");
                var firstString = s.Substring(0, firstSpaceIndex); // INAGX4
                var s1 = Todatetimepicker.Value.ToString("yyyy-MM-dd hh:mm:ss");
                var firstSpaceIndex1 = s1.IndexOf(" ");
                var firstString1 = s1.Substring(0, firstSpaceIndex); // INAGX4
                positions = db.GetPositionData(firstString + " " + FromTimeTextbox.Text, firstString1 + " " + ToTimeTextbox.Text);

                //var chart = chart1.ChartAreas[0];
                chart1.ChartAreas[0].AxisX.ScaleView.Zoomable = true;
                chart1.ChartAreas[0].AxisY.ScaleView.Zoomable = true;
                chart1.MouseWheel += chart1_MouseWheel;
                //chart.AxisX.IntervalType = System.Windows.Forms.DataVisualization.Charting.DateTimeIntervalType.Number;
                //chart.AxisX.LabelStyle.Format = "yyyy-MM-dd HH:mm:ss";
                //chart.AxisY.LabelStyle.Format = "";
                //chart.AxisX.LabelStyle.IsEndLabelVisible = true;

                // chart.AxisY.Maximum = 200;
                //chart.AxisY.Minimum = 0;
                //chart.AxisY.Interval = 0.01;
                //chart.AxisX.Interval = 0.1;
                
                //chart1.ChartAreas[0].AxisX.LabelStyle.Format = "yyyy/MM/dd HH:mm:ss";

                string[] et = new string[positions.Count + 1];
                for (int i = 0; i < positions.Count; i++)
                {
                    et[i] = positions[i].entrytime;
                }
                float[] p = new float[positions.Count + 1];

                if (checkedListBox.GetItemChecked(0))
                {
                    for (int i = 0; i < positions.Count; i++)
                    {
                        p[i] = positions[i].PositionData[0];
                    }
                    chart1.Series.Add("Position 1");
                    //chart1.Series["Position 1"].IsValueShownAsLabel = true;
                    chart1.Series["Position 1"].BorderWidth = 3;
                    chart1.Series["Position 1"].ChartType = SeriesChartType.Line;
                    //chart1.Series["Position 1"].Points.DataBindY(p);
                    chart1.Series["Position 1"].Points.DataBindXY(et, p);
                }

                if (checkedListBox.GetItemChecked(1))
                {
                    for (int i = 0; i < positions.Count; i++)
                    {
                        p[i] = positions[i].PositionData[1];
                    }
                    chart1.Series.Add("Position 2");
                    //chart1.Series["Position 2"].IsValueShownAsLabel = true;
                    chart1.Series["Position 2"].BorderWidth = 3;
                    chart1.Series["Position 2"].ChartType = SeriesChartType.Line;
                    chart1.Series["Position 2"].Points.DataBindY(p);
                }
                if (checkedListBox.GetItemChecked(2))
                {
                    for (int i = 0; i < positions.Count; i++)
                    {
                        p[i] = positions[i].PositionData[2];
                    }
                    chart1.Series.Add("Position 3");
                    //chart1.Series["Position 3"].IsValueShownAsLabel = true;
                    chart1.Series["Position 3"].BorderWidth = 3;
                    chart1.Series["Position 3"].ChartType = SeriesChartType.Line;
                    chart1.Series["Position 3"].Points.DataBindY(p);
                }
                if (checkedListBox.GetItemChecked(3))
                {
                    for (int i = 0; i < positions.Count; i++)
                    {
                        p[i] = positions[i].PositionData[3];
                    }
                    chart1.Series.Add("Position 4");
                    //chart1.Series["Position 4"].IsValueShownAsLabel = true;
                    chart1.Series["Position 4"].BorderWidth = 3;
                    chart1.Series["Position 4"].ChartType = SeriesChartType.Line;
                    chart1.Series["Position 4"].Points.DataBindY(p);
                }
                if (checkedListBox.GetItemChecked(4))
                {
                    for (int i = 0; i < positions.Count; i++)
                    {
                        p[i] = positions[i].PositionData[4];
                    }
                    chart1.Series.Add("Position 5");
                    //chart1.Series["Position 5"].IsValueShownAsLabel = true;
                    chart1.Series["Position 5"].BorderWidth = 3;
                    chart1.Series["Position 5"].ChartType = SeriesChartType.Line;
                    chart1.Series["Position 5"].Points.DataBindY(p);
                }
                if (checkedListBox.GetItemChecked(5))
                {
                    for (int i = 0; i < positions.Count; i++)
                    {
                        p[i] = positions[i].PositionData[5];
                    }
                    chart1.Series.Add("Position 6");
                    //chart1.Series["Position 6"].IsValueShownAsLabel = true;
                    chart1.Series["Position 6"].BorderWidth = 3;
                    chart1.Series["Position 6"].ChartType = SeriesChartType.Line;
                    chart1.Series["Position 6"].Points.DataBindY(p);
                }
                if (checkedListBox.GetItemChecked(6))
                {
                    for (int i = 0; i < positions.Count; i++)
                    {
                        p[i] = positions[i].PositionData[6];
                    }
                    chart1.Series.Add("Position 7");
                    //chart1.Series["Position 7"].IsValueShownAsLabel = true;
                    chart1.Series["Position 7"].BorderWidth = 3;
                    chart1.Series["Position 7"].ChartType = SeriesChartType.Line;
                    chart1.Series["Position 7"].Points.DataBindY(p);
                }
                if (checkedListBox.GetItemChecked(7))
                {
                    for (int i = 0; i < positions.Count; i++)
                    {
                        p[i] = positions[i].PositionData[7];
                    }
                    chart1.Series.Add("Position 8");
                    //chart1.Series["Position 8"].IsValueShownAsLabel = true;
                    chart1.Series["Position 8"].BorderWidth = 3;
                    chart1.Series["Position 8"].ChartType = SeriesChartType.Line;
                    chart1.Series["Position 8"].Points.DataBindY(p);
                }
                if (checkedListBox.GetItemChecked(8))
                {
                    for (int i = 0; i < positions.Count; i++)
                    {
                        p[i] = positions[i].PositionData[8];
                    }
                    chart1.Series.Add("Position 9");
                    //chart1.Series["Position 9"].IsValueShownAsLabel = true;
                    chart1.Series["Position 9"].BorderWidth = 3;
                    chart1.Series["Position 9"].ChartType = SeriesChartType.Line;
                    chart1.Series["Position 9"].Points.DataBindY(p);
                }
                if (checkedListBox.GetItemChecked(9))
                {
                    for (int i = 0; i < positions.Count; i++)
                    {
                        p[i] = positions[i].PositionData[9];
                    }
                    chart1.Series.Add("Position 10");
                    //chart1.Series["Position 10"].IsValueShownAsLabel = true;
                    chart1.Series["Position 10"].BorderWidth = 3;
                    chart1.Series["Position 10"].ChartType = SeriesChartType.Line;
                    chart1.Series["Position 10"].Points.DataBindY(p);
                }
                if (checkedListBox.GetItemChecked(10))
                {
                    for (int i = 0; i < positions.Count; i++)
                    {
                        p[i] = positions[i].PositionData[10];
                    }
                    chart1.Series.Add("Position 11");
                    //chart1.Series["Position 11"].IsValueShownAsLabel = true;
                    chart1.Series["Position 11"].BorderWidth = 3;
                    chart1.Series["Position 11"].ChartType = SeriesChartType.Line;
                    chart1.Series["Position 11"].Points.DataBindY(p);
                }
                if (checkedListBox.GetItemChecked(11))
                {
                    for (int i = 0; i < positions.Count; i++)
                    {
                        p[i] = positions[i].PositionData[11];
                    }
                    chart1.Series.Add("Position 12");
                    //chart1.Series["Position 12"].IsValueShownAsLabel = true;
                    chart1.Series["Position 12"].BorderWidth = 3;
                    chart1.Series["Position 12"].ChartType = SeriesChartType.Line;
                    chart1.Series["Position 12"].Points.DataBindY(p);
                }
                if (checkedListBox.GetItemChecked(12))
                {
                    for (int i = 0; i < positions.Count; i++)
                    {
                        p[i] = positions[i].PositionData[12];
                    }
                    chart1.Series.Add("Position 13");
                    //chart1.Series["Position 13"].IsValueShownAsLabel = true;
                    chart1.Series["Position 13"].BorderWidth = 3;
                    chart1.Series["Position 13"].ChartType = SeriesChartType.Line;
                    chart1.Series["Position 13"].Points.DataBindY(p);
                }
                if (checkedListBox.GetItemChecked(13))
                {
                    for (int i = 0; i < positions.Count; i++)
                    {
                        p[i] = positions[i].PositionData[13];
                    }
                    chart1.Series.Add("Position 14");
                    //chart1.Series["Position 14"].IsValueShownAsLabel = true;
                    chart1.Series["Position 14"].BorderWidth = 3;
                    chart1.Series["Position 14"].ChartType = SeriesChartType.Line;
                    chart1.Series["Position 14"].Points.DataBindY(p);
                }
                if (checkedListBox.GetItemChecked(14))
                {
                    for (int i = 0; i < positions.Count; i++)
                    {
                        p[i] = positions[i].PositionData[14];
                    }
                    chart1.Series.Add("Position 15");
                    //chart1.Series["Position 15"].IsValueShownAsLabel = true;
                    chart1.Series["Position 15"].BorderWidth = 3;
                    chart1.Series["Position 15"].ChartType = SeriesChartType.Line;
                    chart1.Series["Position 15"].Points.DataBindY(p);
                }
                if (checkedListBox.GetItemChecked(15))
                {
                    for (int i = 0; i < positions.Count; i++)
                    {
                        p[i] = positions[i].PositionData[15];
                    }
                    chart1.Series.Add("Position 16");
                    //chart1.Series["Position 16"].IsValueShownAsLabel = true;
                    chart1.Series["Position 16"].BorderWidth = 3;
                    chart1.Series["Position 16"].ChartType = SeriesChartType.Line;
                    chart1.Series["Position 16"].Points.DataBindY(p);
                }
                if (checkedListBox.GetItemChecked(16))
                {
                    for (int i = 0; i < positions.Count; i++)
                    {
                        p[i] = positions[i].PositionData[16];
                    }
                    chart1.Series.Add("Position 17");
                    //chart1.Series["Position 17"].IsValueShownAsLabel = true;
                    chart1.Series["Position 17"].BorderWidth = 3;
                    chart1.Series["Position 17"].ChartType = SeriesChartType.Line;
                    chart1.Series["Position 17"].Points.DataBindY(p);
                }
                if (checkedListBox.GetItemChecked(17))
                {
                    for (int i = 0; i < positions.Count; i++)
                    {
                        p[i] = positions[i].PositionData[17];
                    }
                    chart1.Series.Add("Position 18");
                    //chart1.Series["Position 18"].IsValueShownAsLabel = true;
                    chart1.Series["Position 18"].BorderWidth = 3;
                    chart1.Series["Position 18"].ChartType = SeriesChartType.Line;
                    chart1.Series["Position 18"].Points.DataBindY(p);
                }
                if (checkedListBox.GetItemChecked(18))
                {
                    for (int i = 0; i < positions.Count; i++)
                    {
                        p[i] = positions[i].PositionData[18];
                    }
                    chart1.Series.Add("Position 19");
                    //chart1.Series["Position 19"].IsValueShownAsLabel = true;
                    chart1.Series["Position 19"].BorderWidth = 3;
                    chart1.Series["Position 19"].ChartType = SeriesChartType.Line;
                    chart1.Series["Position 19"].Points.DataBindY(p);
                }
                if (checkedListBox.GetItemChecked(19))
                {
                    for (int i = 0; i < positions.Count; i++)
                    {
                        p[i] = positions[i].PositionData[19];
                    }
                    chart1.Series.Add("Position 20");
                    //chart1.Series["Position 20"].IsValueShownAsLabel = true;
                    chart1.Series["Position 20"].BorderWidth = 3;
                    chart1.Series["Position 20"].ChartType = SeriesChartType.Line;
                    chart1.Series["Position 20"].Points.DataBindY(p);
                }
                if (checkedListBox.GetItemChecked(20))
                {
                    for (int i = 0; i < positions.Count; i++)
                    {
                        p[i] = positions[i].PositionData[20];
                    }
                    chart1.Series.Add("Position 21");
                    //chart1.Series["Position 21"].IsValueShownAsLabel = true;
                    chart1.Series["Position 21"].BorderWidth = 3;
                    chart1.Series["Position 21"].ChartType = SeriesChartType.Line;
                    chart1.Series["Position 21"].Points.DataBindY(p);
                }
                if (checkedListBox.GetItemChecked(21))
                {
                    for (int i = 0; i < positions.Count; i++)
                    {
                        p[i] = positions[i].PositionData[21];
                    }
                    chart1.Series.Add("Position 22");
                    //chart1.Series["Position 22"].IsValueShownAsLabel = true;
                    chart1.Series["Position 22"].BorderWidth = 3;
                    chart1.Series["Position 22"].ChartType = SeriesChartType.Line;
                    chart1.Series["Position 22"].Points.DataBindY(p);
                }
                if (checkedListBox.GetItemChecked(22))
                {
                    for (int i = 0; i < positions.Count; i++)
                    {
                        p[i] = positions[i].PositionData[22];
                    }
                    chart1.Series.Add("Position 23");
                    //chart1.Series["Position 23"].IsValueShownAsLabel = true;
                    chart1.Series["Position 23"].BorderWidth = 3;
                    chart1.Series["Position 23"].ChartType = SeriesChartType.Line;
                    chart1.Series["Position 23"].Points.DataBindY(p);
                }
                if (checkedListBox.GetItemChecked(23))
                {
                    for (int i = 0; i < positions.Count; i++)
                    {
                        p[i] = positions[i].PositionData[23];
                    }
                    chart1.Series.Add("Position 24");
                    //chart1.Series["Position 24"].IsValueShownAsLabel = true;
                    chart1.Series["Position 24"].BorderWidth = 3;
                    chart1.Series["Position 24"].ChartType = SeriesChartType.Line;
                    chart1.Series["Position 24"].Points.DataBindY(p);
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(this, ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void ShowValuesButton_Click(object sender, EventArgs e)
        {
            try
            {
                var s = FromDatetimepicker.Value.ToString("yyyy-MM-dd hh:mm:ss");
                var firstSpaceIndex = s.IndexOf(" ");
                var firstString = s.Substring(0, firstSpaceIndex); // INAGX4
                var s1 = Todatetimepicker.Value.ToString("yyyy-MM-dd hh:mm:ss");
                var firstSpaceIndex1 = s1.IndexOf(" ");
                var firstString1 = s1.Substring(0, firstSpaceIndex); // INAGX4
                positions = db.GetPositionData(firstString + " " + FromTimeTextbox.Text, firstString1 + " " + ToTimeTextbox.Text);
                dataGridView.DataSource = positions;
            }
            catch (Exception ex)
            {

                MessageBox.Show(this, ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
             
        }
    }
}
