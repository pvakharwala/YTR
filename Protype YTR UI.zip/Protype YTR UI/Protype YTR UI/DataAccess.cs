﻿using Dapper;
using Protype_YTR_UI.Properties;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Protype_YTR_UI
{
    public class DataAccess
    {
        public List<Position> GetPositionData(string fromdatetime, string tilldatetime)
        {
            string cnnstring = Settings.Default["SQLConnectionStringSetting"].ToString();
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal(cnnstring)))
            {
                //                SELECT*
                //FROM dbo.CN WHERE  datetime
                //BETWEEN CONVERT(timestamp, '2013-03-24 23:59:59') AND CONVERT(timestamp, '2013-03-26 23:59:59')
                //var output = connection.Query<Person>($"select * from People where LastName = '{ lastName }'").ToList();
                //"dbo.People_GetByLastName @LastName", new { LastName = lastName }
                //direct query is given below
                //"SELECT * FROM dbo.CN WHERE  entrytime BETWEEN CAST('"+fromdatetime+"' AS datetime) AND CAST('"+tilldatetime+"' AS datetime)"
                var output = connection.Query<Position>("dbo.CN_get @startdatetime, @enddatetime", new { startdatetime = fromdatetime, enddatetime = tilldatetime }).ToList();
                return output;
            }
        }

        public List<Position> GetLastRow()
        {
            string cnnstring = Settings.Default["SQLConnectionStringSetting"].ToString();
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal(cnnstring)))
            {
                //SELECT TOP 1 * FROm dbo.CN ORDER BY entrytime DESC
                var output = connection.Query<Position>("SELECT TOP 1 * FROm dbo.CN ORDER BY entrytime DESC").ToList();
                return output;
            }
        }


        public void InsertPositionData(float poss1, float poss2, float poss3, float poss4, float poss5, float poss6, float poss7, float poss8, float poss9, float poss10, float poss11, float poss12,
                float poss13, float poss14, float poss15, float poss16, float poss17, float poss18, float poss19, float poss20, float poss21, float poss22, float poss23, float poss24)
        {
            string cnnstring = Settings.Default["SQLConnectionStringSetting"].ToString();
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal(cnnstring)))
            {
                //Person newPerson = new Person { FirstName = firstName, LastName = lastName, EmailAddress = emailAddress, PhoneNumber = phoneNumber };
                //List<Position> position = new List<Position>();

                //position.Add(new Position
                //{
                //    Position1 = pos1,
                //    Position2 = pos2,
                //    Position3 = pos3,
                //    Position4 = pos4,
                //    Position5 = pos5,
                //    Position6 = pos6,
                //    Position7 = pos7,
                //    Position8 = pos8,
                //    Position9 = pos9,
                //    Position10 = pos10,
                //    Position11 = pos11,
                //    Position12 = pos12,
                //    Position13 = pos13,
                //    Position14 = pos14,
                //    Position15 = pos15,
                //    Position16 = pos16,
                //    Position17 = pos17,
                //    Position18 = pos18,
                //    Position19 = pos19,
                //    Position20 = pos20,
                //    Position21 = pos21,
                //    Position22 = pos22,
                //    Position23 = pos23,
                //    Position24 = pos24
                //});
                
                connection.Execute("dbo.CN_insert @pos1, @pos2, @pos3, @pos4, @pos5, @pos6, @pos7, @pos8, @pos9, @pos10, @pos11, @pos12, @pos13, @pos14, @pos15, " +
                    "@pos16, @pos17, @pos18, @pos19, @pos20, @pos21, @pos22, @pos23, @pos24", new { pos1 = poss1, pos2 = poss2, pos3 = poss3, pos4 = poss4, pos5 = poss5, pos6 = poss6,
                        pos7 = poss7, pos8 = poss8, pos9 = poss9, pos10 = poss10, pos11 = poss11, pos12 = poss12,
                        pos13 = poss13, pos14 = poss14, pos15 = poss15, pos16 = poss16, pos17 = poss17, pos18 = poss18, pos19 = poss19, pos20 = poss20, pos21 = poss21, pos22 = poss22, pos23 = poss23, pos24 = poss24,
                    });

            }
        }
    }
}
