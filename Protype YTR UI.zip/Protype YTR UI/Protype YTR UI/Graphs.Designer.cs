﻿
namespace Protype_YTR_UI
{
    partial class Graphs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.FromDatetimepicker = new System.Windows.Forms.DateTimePicker();
            this.Todatetimepicker = new System.Windows.Forms.DateTimePicker();
            this.FromLabel = new System.Windows.Forms.Label();
            this.FromTimeTextbox = new System.Windows.Forms.TextBox();
            this.ToLabel = new System.Windows.Forms.Label();
            this.ToTimeTextbox = new System.Windows.Forms.TextBox();
            this.GetGraphButton = new System.Windows.Forms.Button();
            this.ShowValuesButton = new System.Windows.Forms.Button();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.checkedListBox = new System.Windows.Forms.CheckedListBox();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // FromDatetimepicker
            // 
            this.FromDatetimepicker.Location = new System.Drawing.Point(63, 16);
            this.FromDatetimepicker.Name = "FromDatetimepicker";
            this.FromDatetimepicker.Size = new System.Drawing.Size(200, 20);
            this.FromDatetimepicker.TabIndex = 0;
            // 
            // Todatetimepicker
            // 
            this.Todatetimepicker.Location = new System.Drawing.Point(454, 16);
            this.Todatetimepicker.Name = "Todatetimepicker";
            this.Todatetimepicker.Size = new System.Drawing.Size(200, 20);
            this.Todatetimepicker.TabIndex = 1;
            // 
            // FromLabel
            // 
            this.FromLabel.AutoSize = true;
            this.FromLabel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FromLabel.Location = new System.Drawing.Point(15, 16);
            this.FromLabel.Name = "FromLabel";
            this.FromLabel.Size = new System.Drawing.Size(45, 19);
            this.FromLabel.TabIndex = 2;
            this.FromLabel.Text = "From:";
            // 
            // FromTimeTextbox
            // 
            this.FromTimeTextbox.Location = new System.Drawing.Point(269, 17);
            this.FromTimeTextbox.Name = "FromTimeTextbox";
            this.FromTimeTextbox.Size = new System.Drawing.Size(100, 20);
            this.FromTimeTextbox.TabIndex = 3;
            this.FromTimeTextbox.Text = "0:0:0";
            // 
            // ToLabel
            // 
            this.ToLabel.AutoSize = true;
            this.ToLabel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ToLabel.Location = new System.Drawing.Point(423, 17);
            this.ToLabel.Name = "ToLabel";
            this.ToLabel.Size = new System.Drawing.Size(28, 19);
            this.ToLabel.TabIndex = 4;
            this.ToLabel.Text = "To:";
            // 
            // ToTimeTextbox
            // 
            this.ToTimeTextbox.Location = new System.Drawing.Point(660, 16);
            this.ToTimeTextbox.Name = "ToTimeTextbox";
            this.ToTimeTextbox.Size = new System.Drawing.Size(100, 20);
            this.ToTimeTextbox.TabIndex = 5;
            this.ToTimeTextbox.Text = "0:0:0";
            // 
            // GetGraphButton
            // 
            this.GetGraphButton.Location = new System.Drawing.Point(19, 52);
            this.GetGraphButton.Name = "GetGraphButton";
            this.GetGraphButton.Size = new System.Drawing.Size(75, 23);
            this.GetGraphButton.TabIndex = 6;
            this.GetGraphButton.Text = "Get Graph";
            this.GetGraphButton.UseVisualStyleBackColor = true;
            this.GetGraphButton.Click += new System.EventHandler(this.GetGraphButton_Click);
            // 
            // ShowValuesButton
            // 
            this.ShowValuesButton.Location = new System.Drawing.Point(114, 52);
            this.ShowValuesButton.Name = "ShowValuesButton";
            this.ShowValuesButton.Size = new System.Drawing.Size(75, 23);
            this.ShowValuesButton.TabIndex = 7;
            this.ShowValuesButton.Text = "Show Values";
            this.ShowValuesButton.UseVisualStyleBackColor = true;
            this.ShowValuesButton.Click += new System.EventHandler(this.ShowValuesButton_Click);
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabPage1);
            this.tabControl.Controls.Add(this.tabPage2);
            this.tabControl.Location = new System.Drawing.Point(7, 81);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(1256, 569);
            this.tabControl.TabIndex = 8;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.checkedListBox);
            this.tabPage1.Controls.Add(this.chart1);
            this.tabPage1.Location = new System.Drawing.Point(4, 23);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1248, 542);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Line Chart";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // checkedListBox
            // 
            this.checkedListBox.CheckOnClick = true;
            this.checkedListBox.FormattingEnabled = true;
            this.checkedListBox.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.checkedListBox.Items.AddRange(new object[] {
            "Position 1",
            "Position 2",
            "Position 3",
            "Position 4",
            "Position 5",
            "Position 6",
            "Position 7",
            "Position 8",
            "Position 9",
            "Position 10",
            "Position 11",
            "Position 12",
            "Position 13",
            "Position 14",
            "Position 15",
            "Position 16",
            "Position 17",
            "Position 18",
            "Position 19",
            "Position 20",
            "Position 21",
            "Position 22",
            "Position 23",
            "Position 24"});
            this.checkedListBox.Location = new System.Drawing.Point(1142, 26);
            this.checkedListBox.Name = "checkedListBox";
            this.checkedListBox.Size = new System.Drawing.Size(106, 484);
            this.checkedListBox.TabIndex = 1;
            // 
            // chart1
            // 
            chartArea2.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.chart1.Legends.Add(legend2);
            this.chart1.Location = new System.Drawing.Point(0, 4);
            this.chart1.Name = "chart1";
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            this.chart1.Series.Add(series2);
            this.chart1.Size = new System.Drawing.Size(1145, 532);
            this.chart1.TabIndex = 0;
            this.chart1.Text = "chart1";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.dataGridView);
            this.tabPage2.Location = new System.Drawing.Point(4, 23);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1248, 542);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Values";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // dataGridView
            // 
            this.dataGridView.AllowUserToOrderColumns = true;
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.Location = new System.Drawing.Point(4, 4);
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.ReadOnly = true;
            this.dataGridView.Size = new System.Drawing.Size(1241, 534);
            this.dataGridView.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(617, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(143, 14);
            this.label1.TabIndex = 9;
            this.label1.Text = "Enter time in 24Hr hh:mm:ss";
            // 
            // Graphs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1264, 655);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tabControl);
            this.Controls.Add(this.ShowValuesButton);
            this.Controls.Add(this.GetGraphButton);
            this.Controls.Add(this.ToTimeTextbox);
            this.Controls.Add(this.ToLabel);
            this.Controls.Add(this.FromTimeTextbox);
            this.Controls.Add(this.FromLabel);
            this.Controls.Add(this.Todatetimepicker);
            this.Controls.Add(this.FromDatetimepicker);
            this.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Graphs";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Graphs";
            this.Load += new System.EventHandler(this.Graphs_Load);
            this.tabControl.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker FromDatetimepicker;
        private System.Windows.Forms.DateTimePicker Todatetimepicker;
        private System.Windows.Forms.Label FromLabel;
        private System.Windows.Forms.TextBox FromTimeTextbox;
        private System.Windows.Forms.Label ToLabel;
        private System.Windows.Forms.TextBox ToTimeTextbox;
        private System.Windows.Forms.Button GetGraphButton;
        private System.Windows.Forms.Button ShowValuesButton;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckedListBox checkedListBox;
    }
}