﻿using EasyModbus;
using Protype_YTR_UI.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace Protype_YTR_UI
{
    public partial class MainWindow : Form
    {
        string s = DateTime.Now.AddSeconds(-5).ToString("yyyy-MM-dd HH:mm:ss");
        DataAccess db = new DataAccess();
        float[] readHoldingRegistersGlobal = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        int threadcount = 0;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void buttonparan_Click(object sender, EventArgs e)
        {

        }

        private void MainWindow_Load(object sender, EventArgs e)
        {
            Tx.Text = "0";
            Rx.Text = "0";

            PL1.Text = "0";
            PL2.Text = "0";
            PL3.Text = "0";
            PL4.Text = "0";
            PL5.Text = "0";
            PL6.Text = "0";
            PL7.Text = "0";
            PL8.Text = "0";
            PL9.Text = "0";
            PL10.Text = "0";
            PL11.Text = "0";
            PL12.Text = "0";
            PL13.Text = "0";
            PL14.Text = "0";
            PL15.Text = "0";
            PL16.Text = "0";
            PL17.Text = "0";
            PL18.Text = "0";
            PL19.Text = "0";
            PL20.Text = "0";
            PL21.Text = "0";
            PL22.Text = "0";
            PL23.Text = "0";
            PL24.Text = "0";

            chart1.Series.Clear();
            chart1.Series.Add("Positions");
            chart1.Series["Positions"].IsVisibleInLegend = false;
            chart1.ChartAreas[0].AxisX.Interval = 1;
            chart1.ChartAreas[0].AxisY.Maximum = 150;
            //chart1.ChartAreas[0].AxisY.Interval = 5;
            chart1.ChartAreas[0].AxisY.ScaleView.Zoomable = true;
            chart1.MouseWheel += chart1_MouseWheel;

            chart1.ChartAreas[0].AxisY.Title = "Centi-Newton";
            chart1.Series["Positions"].Points.DataBindY(readHoldingRegistersGlobal);
        }

        private void chart1_MouseWheel(object sender, MouseEventArgs e)
        {
            var chart = (Chart)sender;
            var yAxis = chart.ChartAreas[0].AxisY;

            try
            {
                if (e.Delta < 0) // Scrolled down.
                {
                    yAxis.ScaleView.ZoomReset();
                }
                else if (e.Delta > 0) // Scrolled up.
                {
                    var yMin = yAxis.ScaleView.ViewMinimum;
                    var yMax = yAxis.ScaleView.ViewMaximum;

                    var posYStart = yAxis.PixelPositionToValue(e.Location.Y) - (yMax - yMin) / 4;
                    var posYFinish = yAxis.PixelPositionToValue(e.Location.Y) + (yMax - yMin) / 4;

                    yAxis.ScaleView.Zoom(posYStart, posYFinish);
                }
            }
            catch { }
        }

        private void ConfigureSystemButton_Click(object sender, EventArgs e)
        {

            string message = "Do you want to stop logging and open Configure window?";
            string title = "Alert!";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result = MessageBox.Show(message, title, buttons, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
            if (result == DialogResult.Yes)
            {
                StopLoggingButton.PerformClick();
                var startconfigure = new Configure();
                startconfigure.ShowDialog();
            }
            else
            {
                // Do something  
            }
            
        }

        private void StopLoggingButton_Click(object sender, EventArgs e)
        {
            //if (loggingthread.IsAlive)
            //{
            //    loggingthread.Abort();

            //}
            //else
            //{
            //    MessageBox.Show("Not Logging Anyway", "Alert!");
            //}
            // _canceller.Cancel();
            threadcount = 0;
        }

        private void ShowGraphDataButton_Click(object sender, EventArgs e)
        {
            string message = "Do you want to stop logging and open Graphs window? \r\n Note: The rendering time depends on the amount of Data \r\n points and processing power. \r\n " +
                "Please wait while the system renders!";
            string title = "Alert!";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result = MessageBox.Show(message, title, buttons, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
            if (result == DialogResult.Yes)
            {
                StopLoggingButton.PerformClick();
                var startgraphs = new Graphs();
                startgraphs.ShowDialog();
            }
            else
            {
                // Do something  
            }

            
        }
        private CancellationTokenSource _canceller;
        private async void StartLoggingButton_Click(object sender, EventArgs e)
        {
            StartLoggingButton.Enabled = false;
            StopLoggingButton.Enabled = true;
            //_canceller = new CancellationTokenSource();
            s = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            threadcount = 1;
             await logging();
            //_canceller.Dispose();
            StartLoggingButton.Enabled = true;
            StopLoggingButton.Enabled = false;
            //logging();
        }

        private async Task logging()
        {
            int firsttime = 0;
            //dataGridView1.Rows.Clear();
            //dataGridView1.Refresh();
            //DataGridViewColumn column = dataGridView1.Columns[0];
            //column.Width = 160;
            int datacount = 0;

            long tx = 0;
            long rx = 0;
            Tx.Text = tx.ToString();
            Rx.Text = rx.ToString();

            while (threadcount == 1)
            {
                await Task.Run(() =>
                {
                        //var numbers = Settings.Default["TareSetting"].ToString().Split(',').Select(float.Parse).ToList();
                        //float[] tare = numbers.ToArray();
                        //numbers = Settings.Default["SetScaleSetting"].ToString().Split(',').Select(float.Parse).ToList();
                        //float[] setscale = numbers.ToArray();
                        int port = int.Parse(Settings.Default["PortSetting"].ToString());

                    while (datacount<1)
                    {
                        tx += 1;
                        try
                        {
                            string ipslave1 = Settings.Default["IPSlave1Setting"].ToString();
                            ModbusClient modbusClient = new ModbusClient(ipslave1, port);
                            modbusClient.ConnectionTimeout = 10;
                            modbusClient.Connect();
                            int[] readHoldingRegisters = modbusClient.ReadHoldingRegisters(0, 12);
                            modbusClient.Disconnect();
                            for (int i = 0; i < 12; i++)
                            {
                                readHoldingRegistersGlobal[i] = readHoldingRegisters[i];
                            }
                            rx += 1;
                        }
                        catch (Exception ex)
                        {
                            for (int i = 0; i < 12; i++)
                            {
                                readHoldingRegistersGlobal[i] = 0;
                            }
                            //MessageBox.Show(this, ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            Console.WriteLine(ex.Message);
                            rx -= 1;
                        }

                        try
                        {
                            string ipslave2 = Settings.Default["IPSlave2Setting"].ToString();
                            ModbusClient modbusClient2 = new ModbusClient(ipslave2, port);
                            modbusClient2.ConnectionTimeout = 10;
                            modbusClient2.Connect();
                            int[] readHoldingRegisters2 = modbusClient2.ReadHoldingRegisters(0, 12);
                            modbusClient2.Disconnect();
                            for (int i = 0; i < 12; i++)
                            {
                                readHoldingRegistersGlobal[i + 12] = readHoldingRegisters2[i]; 
                            }
                            rx += 1;
                        }
                        catch (Exception ex)
                        {
                            for (int i = 0; i < 12; i++)
                            {
                                readHoldingRegistersGlobal[i + 12] = 0;
                            }
                            //MessageBox.Show(this, ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            Console.WriteLine(ex.Message);
                            rx -= 1;
                        }
                        datacount = datacount + 1;
                        if (rx<0 || rx>9999999)
                        {
                            rx = 0;
                        }
                        if (tx < 0 || tx > 9999999)
                        {
                            rx = 0;
                        }
                    }

                    datacount = 0;
                    for (int i = 0; i < readHoldingRegistersGlobal.Length; i++)
                    {
                        if (readHoldingRegistersGlobal[i]<0)
                        {
                            readHoldingRegistersGlobal[i] = 0;
                        }
                        readHoldingRegistersGlobal[i] = readHoldingRegistersGlobal[i] / 10;
                    }

                    try
                        {
                            db.InsertPositionData(readHoldingRegistersGlobal[0], readHoldingRegistersGlobal[1], readHoldingRegistersGlobal[2],
                                readHoldingRegistersGlobal[3], readHoldingRegistersGlobal[4], readHoldingRegistersGlobal[5], readHoldingRegistersGlobal[6],
                                readHoldingRegistersGlobal[7], readHoldingRegistersGlobal[8], readHoldingRegistersGlobal[9], readHoldingRegistersGlobal[10],
                                readHoldingRegistersGlobal[11], readHoldingRegistersGlobal[12], readHoldingRegistersGlobal[13], readHoldingRegistersGlobal[14],
                                readHoldingRegistersGlobal[15], readHoldingRegistersGlobal[16], readHoldingRegistersGlobal[17], readHoldingRegistersGlobal[18],
                                readHoldingRegistersGlobal[19], readHoldingRegistersGlobal[20], readHoldingRegistersGlobal[21], readHoldingRegistersGlobal[22],
                                readHoldingRegistersGlobal[23]);
                            Console.WriteLine("Data sent to sql");

                        }
                        catch (Exception ex)
                        {

                            //MessageBox.Show(this, ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            Console.WriteLine(ex.Message);
                        }

                    Thread.Sleep(10);
                });
                //try
                //{
                //    //List<Position> positions = new List<Position>();


                //    //var s1 = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                //    //positions = db.GetLastRow();
                //    List<Position> positions = new List<Position>();
                //    positions = db.GetLastRow();
                //    dataGridView1.Rows.Add(positions[0].entrytime, positions[0].Position1, positions[0].Position2, positions[0].Position3, positions[0].Position4, positions[0].Position5, positions[0].Position6,
                //         positions[0].Position7, positions[0].Position8, positions[0].Position9, positions[0].Position10, positions[0].Position11, positions[0].Position12, positions[0].Position13,
                //         positions[0].Position14, positions[0].Position15, positions[0].Position16, positions[0].Position17, positions[0].Position18, positions[0].Position19, positions[0].Position20,
                //         positions[0].Position21, positions[0].Position22, positions[0].Position23, positions[0].Position24);
                //    if (dataGridView1.Rows.Count > 500)
                //    {
                //        dataGridView1.Rows.Remove(dataGridView1.Rows[0]);
                //    }
                //    Console.WriteLine("data retrived from sql");
                //}
                //catch (Exception ex)
                //{
                //    Console.WriteLine(ex.Message);
                //}
                
                //Random r = new Random();
                //readHoldingRegistersGlobal[0] = r.Next(0, 10);
                chart1.Series["Positions"].Points.DataBindY(readHoldingRegistersGlobal);
                
                Tx.Text = tx.ToString();
                Rx.Text = rx.ToString();

                PL1.Text = readHoldingRegistersGlobal[0].ToString();
                PL2.Text = readHoldingRegistersGlobal[1].ToString();
                PL3.Text = readHoldingRegistersGlobal[2].ToString();
                PL4.Text = readHoldingRegistersGlobal[3].ToString();
                PL5.Text = readHoldingRegistersGlobal[4].ToString();
                PL6.Text = readHoldingRegistersGlobal[5].ToString();
                PL7.Text = readHoldingRegistersGlobal[6].ToString();
                PL8.Text = readHoldingRegistersGlobal[7].ToString();
                PL9.Text = readHoldingRegistersGlobal[8].ToString();
                PL10.Text = readHoldingRegistersGlobal[9].ToString();
                PL11.Text = readHoldingRegistersGlobal[10].ToString();
                PL12.Text = readHoldingRegistersGlobal[11].ToString();
                PL13.Text = readHoldingRegistersGlobal[12].ToString();
                PL14.Text = readHoldingRegistersGlobal[13].ToString();
                PL15.Text = readHoldingRegistersGlobal[14].ToString();
                PL16.Text = readHoldingRegistersGlobal[15].ToString();
                PL17.Text = readHoldingRegistersGlobal[16].ToString();
                PL18.Text = readHoldingRegistersGlobal[17].ToString();
                PL19.Text = readHoldingRegistersGlobal[18].ToString();
                PL20.Text = readHoldingRegistersGlobal[19].ToString();
                PL21.Text = readHoldingRegistersGlobal[20].ToString();
                PL22.Text = readHoldingRegistersGlobal[21].ToString();
                PL23.Text = readHoldingRegistersGlobal[22].ToString();
                PL24.Text = readHoldingRegistersGlobal[23].ToString();
            }
            firsttime = 0;

            tx = 0;
            rx = 0;
            Tx.Text = tx.ToString();
            Rx.Text = rx.ToString();
        }
    }
}
